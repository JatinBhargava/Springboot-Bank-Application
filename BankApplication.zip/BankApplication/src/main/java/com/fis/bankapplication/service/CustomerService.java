package com.fis.bankapplication.service;

import java.util.List;

import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.model.Customer;

public interface CustomerService {
	public abstract String addUser(Customer customer);
	public abstract String updateUser(int customerId,String name,String address) throws CustomerNotFoundException;
	public abstract String deleteUser(int customerId) throws CustomerNotFoundException;
	public abstract Customer getUser(int customerId) throws CustomerNotFoundException;
	public abstract List<Customer> getAllCustomer();
}
