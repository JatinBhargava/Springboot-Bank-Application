package com.fis.bankapplication.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.exception.InsufficientBalance;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;


@Repository
@Transactional
public class TransactionDaoImpl implements TransactionDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private AccountDao accountDAO;
	
	@Override
	//deposit the amount in the account
	public String deposit(int accountId, double amount) {
		Account account = entityManager.find(Account.class,accountId);
		
		if(account!=null) {
			if(amount > 0) {
				double currentAmount = account.getBalance();
				double newBalance = currentAmount + amount;
				account.setBalance(newBalance);
				entityManager.merge(account);
				
				Transaction transaction = new Transaction();
				transaction.setTransactionId(transaction.getTransactionId());
				transaction.setAccount(account);
				transaction.setTranscationDate(transaction.getTranscationDate());
				transaction.setModeOfTransaction("Deposit");
				transaction.setFromAccount(accountId);
				transaction.setToAccount(accountId);
				transaction.setAmount(amount);
				
				entityManager.persist(transaction);
			}
		}
		return null;
	}

	@Override
	//withdraw the amount in the account
	public String withdraw(int accountId, double amount) throws InsufficientBalance{
	Account account = entityManager.find(Account.class,accountId);
		
		if(account!=null) {
			if(account.getBalance() > amount) {
				double currentAmount = account.getBalance();
				double newBalance = currentAmount - amount;
				account.setBalance(newBalance);
				entityManager.merge(account);
				
				Transaction transaction = new Transaction();
				transaction.setTransactionId(transaction.getTransactionId());
				transaction.setAccount(account);
				transaction.setTranscationDate(transaction.getTranscationDate());
				transaction.setModeOfTransaction("Withdraw");
				transaction.setFromAccount(accountId);
				transaction.setToAccount(accountId);
				transaction.setAmount(amount);
				
				entityManager.persist(transaction);
			}
			else
			{
				throw new InsufficientBalance("Insufficent amount trying to withdraw");
			}
		}
		return null;
	}

	@Override 
	//fund transfer the amount in the account from another account
	public String fundTransfer(int fromAccountId, int toAccountId, double amount)throws InsufficientBalance {
		Account senderAccount = entityManager.find(Account.class, fromAccountId);
		Account reciverAccount = entityManager.find(Account.class, toAccountId);
		
		if(senderAccount != null && reciverAccount != null) {
			if(amount > 0 && senderAccount.getBalance() > amount) {
				
				double currentReciverAmount = reciverAccount.getBalance();
				double newReciverBalance = currentReciverAmount + amount;
				
				double currentSenderAmount = senderAccount.getBalance();
				double newSenderBalance = currentSenderAmount - amount;
				
				reciverAccount.setBalance(newReciverBalance);
				senderAccount.setBalance(newSenderBalance);
				
				entityManager.merge(reciverAccount);
				entityManager.merge(senderAccount);
				
				Transaction transaction = new Transaction();
				transaction.setTransactionId(transaction.getTransactionId());
				transaction.setTranscationDate(transaction.getTranscationDate());
				transaction.setModeOfTransaction("Fund Transfer");
				transaction.setFromAccount(senderAccount.getAccountId());
				transaction.setToAccount(reciverAccount.getAccountId());
				transaction.setAmount(amount);
				
				entityManager.persist(transaction);
				
			}
			else
			{
				throw new InsufficientBalance("Insufficient amount trying to transfer");
			}
		}
		
		return null;
	}

	@Override
	//show all the transaction from the database
	public List<Transaction> getAllTranscation() {
		return entityManager.createQuery("Select t from Transaction t",Transaction.class).getResultList();
	}

	@Override
	//show all the transaction from the database by the accountId
	public List<Transaction> getAllTranscationByAccountId(int accountId) {
		TypedQuery<Transaction> query = entityManager.createQuery(
				"Select t from Transaction t where t.fromAccount = :accountId",Transaction.class);
				query.setParameter("accountId", accountId);
		return query.getResultList();
	}

}
