package com.fis.bankapplication.service;

import java.util.List;

import com.fis.bankapplication.exception.InsufficientBalance;
import com.fis.bankapplication.model.Transaction;

public interface TransactionService {
	public abstract String deposit(int accountId,double amount);
	public abstract String withdraw(int accountId,double amount) throws InsufficientBalance;
	public abstract String fundTransfer(int fromAccountId,int toAccountId,double amount) throws InsufficientBalance;
	public abstract List<Transaction> getAllTranscation();
	public abstract List<Transaction> getAllTranscationByAccountId(int accountId);
}
