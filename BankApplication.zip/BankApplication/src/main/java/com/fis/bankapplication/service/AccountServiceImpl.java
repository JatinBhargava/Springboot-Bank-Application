package com.fis.bankapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDAO;
	
	@Override
	public String addAccount(Account account) {
		return accountDAO.addAccount(account);
	}

	@Override
	public Account getAccountByAccountId(int accountId) {
		return accountDAO.getAccountByAccountId(accountId);
	}

	@Override
	public String updateAccount(int accountId,double amount) {
		return accountDAO.updateAccount(accountId,amount);
	}

	@Override
	public void deleteAccount(int accountId) {
		accountDAO.deleteAccount(accountId);
	}

	@Override
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		return accountDAO.getAllAccountsByBalanceRange(minBal,maxBal);
	}
	
	public List<Account> getAllAccounts(){
		return accountDAO.getAllAccounts();
	};

}
