package com.fis.bankapplication.exception;

public class InsufficientBalance extends Exception{
	public InsufficientBalance(String string) {
		super(string);
	}
}
