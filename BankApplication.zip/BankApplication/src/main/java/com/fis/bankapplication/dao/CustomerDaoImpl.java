package com.fis.bankapplication.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;

@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private AccountDao accountDAO;
	
	@Override
	//add customer to the database
	public String addUser(Customer customer) {
		entityManager.persist(customer);
		return "Customer added to the database.";
	}

	@Override
	//update customer in the database
	public String updateUser(int customerId,String name,String address) throws CustomerNotFoundException {
		Customer existingCustomer = entityManager.find(Customer.class, customerId);
		Account existingAccount = entityManager.find(Account.class, customerId);
		
		//if customer is exist in the database then account related to that account should also be there
		if((existingCustomer!=null && existingAccount!=null)) {
			existingCustomer.setName(name);
		existingCustomer.setAddress(address);
		existingAccount.setName(name);
		entityManager.merge(existingCustomer);
		entityManager.merge(existingAccount);
		return "Customer Updated Successfully";
		}
		// if only customer is there but no account for that
		else if(existingCustomer!=null) {
			existingCustomer.setName(name);
			existingCustomer.setAddress(address);
			entityManager.merge(existingCustomer);
			return "Customer Updated Successfully";
		}
		else
		{
			throw new CustomerNotFoundException("Customer not found with ID: " + customerId);
		}
		
	}

	@Override
	//deleting the customer in database
	public String deleteUser(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		if(customer != null) {
			entityManager.remove(customer);
			return "Customer deleted.";
		}
		else{
			return "Customer not found in database.";
		}
	}

	@Override
	//show details for user
	public Customer getUser(int customerId) throws CustomerNotFoundException  {
		if(entityManager.find(Customer.class, customerId)!=null) {
			return entityManager.find(Customer.class, customerId);
		}
		else
		{
			throw new CustomerNotFoundException("User not found");
		}
	}

	@Override
	//show all the users in the database
	public List<Customer> getAllCustomer() {
		return entityManager.createQuery("Select c from Customer c",Customer.class).getResultList();
	}

}
