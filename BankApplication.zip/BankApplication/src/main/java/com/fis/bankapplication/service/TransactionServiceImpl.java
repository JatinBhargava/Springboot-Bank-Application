package com.fis.bankapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.TransactionDao;
import com.fis.bankapplication.exception.InsufficientBalance;
import com.fis.bankapplication.model.Transaction;



@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
	private TransactionDao transactionDAO;

	@Override
	public String deposit(int accountId, double amount) {
		return transactionDAO.deposit(accountId, amount);
	}

	@Override
	public String withdraw(int accountId, double amount) throws InsufficientBalance{
		return transactionDAO.withdraw(accountId, amount);
	}

	@Override
	public String fundTransfer(int fromAccountId, int toAccountId, double amount) throws InsufficientBalance{
		return transactionDAO.fundTransfer(fromAccountId, toAccountId, amount);
	}

	@Override
	public List<Transaction> getAllTranscation() {
		return transactionDAO.getAllTranscation();
	}

	@Override
	public List<Transaction> getAllTranscationByAccountId(int accountId) {
		return transactionDAO.getAllTranscationByAccountId(accountId);
	}

}
