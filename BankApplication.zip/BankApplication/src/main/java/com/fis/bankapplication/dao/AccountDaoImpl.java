package com.fis.bankapplication.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Account;

@Repository
@Transactional
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	//add account in the database
	public String addAccount(Account account) {
		entityManager.persist(account);
		return "Account get added to the database.";
	}

	@Override
	//get account by accountId in the database
	public Account getAccountByAccountId(int accountId) {
		return entityManager.createQuery("Select a FROM Account a JOIN FETCH a.customer WHERE a.id = :accountId",
				Account.class).setParameter("accountId", accountId).getSingleResult();
	}

	@Override
	//update account in the database
	public String updateAccount(int accoundId,double amount) {
		Account account = entityManager.find(Account.class, accoundId);
		account.setBalance(amount);
		entityManager.merge(account);
		return "Updated account";
	}

	@Override
	//delete account in the database
	public void deleteAccount(int accountId) {
		Account account = entityManager.find(Account.class, accountId);
		if(account != null) {
			entityManager.remove(account);
		}
	}

	@Override
	//get account by range between in the database
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		TypedQuery<Account> query = entityManager.createQuery(
				"SELECT a FROM Account a WHERE a.balance >= :minBal AND a.balance <= :maxBal",Account.class);
				query.setParameter("minBal",minBal);
				query.setParameter("maxBal",maxBal);
				return query.getResultList();
	}

	@Override
	//get all accounts in the database
	public List<Account> getAllAccounts() {
		return entityManager.createQuery("Select a from Account a",Account.class).getResultList();
		
	}

}
